/**
 *
 */
package jp.ac.asojuku.dq.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.ac.asojuku.dq.dto.EntryInfoDto;
import jp.ac.asojuku.dq.util.ValidateUtils;

/**
 * @author nishino
 * 登録確認画面
 *
 */
public class ConfirmEntryMemberAction extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {


		//値のチェック
		List<String> errList = validate(req);
		if( errList != null && errList.size() > 0 ){
			//エラー発生
			req.setAttribute("errList", errList);
			//データ表示の為、リクエストに取得データを入れなおす
			setToRequestAttribute(req);
			//画面遷移
			RequestDispatcher rd = req.getRequestDispatcher("view/entry.jsp");
			rd.forward(req, resp);
			return;
		}

		//セッションにセット
		setEntryInfoToSession(req);

		//画面遷移
		RequestDispatcher rd = req.getRequestDispatcher("view/confirm.jsp");
		rd.forward(req, resp);
	}

	/**
	 * ＪＳＰから値を取得し、エラーチェックを行う
	 * @param req
	 * @return エラーメッセージのリスト
	 */
	private List<String> validate(HttpServletRequest req){

		List<String> errList = new ArrayList<String>();

		//値の取得
		String name = req.getParameter("name");
		String sex = req.getParameter("sex");
		String password = req.getParameter("password");
		String job = req.getParameter("job");
		String address = req.getParameter("address");
		String birthday = req.getParameter("birthday");
		String targetmons = req.getParameter("targetmons");
		String expoint = req.getParameter("expoint");

		////////////////////////////////
		//エラーチェック
		////////////////////////////////
		//名前
		if( ValidateUtils.chkLenRange(name,1,255) == false ){
			errList.add("名前は1文字以上255文字以下で入力してください");
		}
		//性別
		if( ValidateUtils.isStringRange(sex,new String[]{"0","1"}) == false  ){
			errList.add("性別の値が不正です");
		}
		//パスワード
		if( ValidateUtils.isOkPassword(password) == false ){
			errList.add("パスワードは半角英数記号を最低１種類含み、４文字以上で入力してください");
		}
		//仕事
		if( ValidateUtils.isStringRange(job,
				new String[]{
					"0","1","2","3","4","5","6","7","8","9",
					"10","11","12","13","14","15","16","17","18","19",
					"20","21","22","23"
					})  == false ){
			errList.add("仕事の値が不正です");
		}
		//住所
		if( ValidateUtils.chkLenRange(address,1,255) == false ){
			errList.add("住所は1文字以上255文字以下で入力してください");
		}
		//誕生日
		if( ValidateUtils.isDate(birthday,"yyyy/mm/dd") == false ){
			errList.add("住所は1文字以上255文字以下で入力してください");
		}
		//対戦モンスター
		if( ValidateUtils.chkLenRange(targetmons,1,255) == false ){
			errList.add("対戦したいモンスターは1文字以上255文字以下で入力してください");
		}
		//経験値
		if( ValidateUtils.chkLenRange(expoint,0,10) == false ){
			errList.add("経験値は10文字以下で入力してください");
		}else if( ValidateUtils.isNumeric(expoint) == false ){
			errList.add("経験値は数値で入力してください");
		}

		return errList;
	}

	/**
	 * ＪＳＰから値を取得し、EntryInfoDtoへ格納する
	 * @param req
	 * @return
	 */
	private EntryInfoDto getEntryInfoDto(HttpServletRequest req){
		EntryInfoDto entryInfoDto = new EntryInfoDto();

		//数値変換
		int sex = Integer.parseInt(req.getParameter("sex"));
		int job = Integer.parseInt(req.getParameter("job"));
		int exPoint = Integer.parseInt(req.getParameter("expoint"));

		//値をセット
		entryInfoDto.setName(req.getParameter("name"));
		entryInfoDto.setSex(sex);
		entryInfoDto.setPwd(req.getParameter("password"));
		entryInfoDto.setJob(job);
		entryInfoDto.setAddress(req.getParameter("address"));
		entryInfoDto.setBirthday(req.getParameter("birthday"));
		entryInfoDto.setTargetMons(req.getParameter("targetmons"));
		entryInfoDto.setExpoint(exPoint);

		//経験力レベルを取得
		int level = getLevel(exPoint);
		entryInfoDto.setLevel(level);

		return entryInfoDto;
	}

	/**
	 * ＪＳＰから取得し、エラーチェックした値をセッションに値を保存する
	 * @param req
	 */
	private void setEntryInfoToSession(HttpServletRequest req){

		//値を取得しDTOにセット
		EntryInfoDto entryInfoDto = getEntryInfoDto(req);

		//セッションの取得
		HttpSession session = req.getSession(true);

		session.setAttribute("entryInfoDto", entryInfoDto);

	}

	/**
	 * 経験力レベルを取得する
	 * @param exPoint
	 * @return レベル
	 */
	private int getLevel(int exPoint){
		int lvl = 1;

		if( exPoint < 7 ){
			lvl = 1;
		}else if( exPoint < 23 ){
			lvl = 2;
		}else if( exPoint < 47 ){
			lvl = 3;
		}else if( exPoint < 110 ){
			lvl = 4;
		}else if( exPoint < 220 ){
			lvl = 5;
		}else if( exPoint < 450 ){
			lvl = 6;
		}else if( exPoint < 800 ){
			lvl = 7;
		}else{
			lvl = 8;
		}

		return lvl;
	}

	private void setToRequestAttribute(HttpServletRequest req){

		//値の取得
		String name = req.getParameter("name");
		String sex = req.getParameter("sex");
		String password = req.getParameter("password");
		String job = req.getParameter("job");
		String address = req.getParameter("address");
		String birthday = req.getParameter("birthday");
		String targetmons = req.getParameter("targetmons");
		String expoint = req.getParameter("expoint");

		req.setAttribute("name", name);
		req.setAttribute("sex", sex);
		req.setAttribute("password", password);
		req.setAttribute("job", job);
		req.setAttribute("address", address);
		req.setAttribute("birthday", birthday);
		req.setAttribute("targetmons", targetmons);
		req.setAttribute("expoint", expoint);
	}

}
