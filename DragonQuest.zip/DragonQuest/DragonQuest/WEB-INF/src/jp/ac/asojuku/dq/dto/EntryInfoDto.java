/**
 *
 */
package jp.ac.asojuku.dq.dto;

/**
 * @author nishino
 *
 * 登録データのDTO（Data Transfer Object）
 * 要するにデータの保持クラス
 * 意味のあるデータの塊をまとめて保持する
 */
public class EntryInfoDto {
	/** 性別定数 */
	public static final int MALE = 0;	//男性
	public static final int FEMALE = 1;	//女性

	/** 名前 */
	private String name;
	/** 性別 */
	private int sex;
	/** パスワード */
	private String pwd;
	/** 希望する職種 */
	private int job;
	/** 住所 */
	private String address;
	/** 生年月日 */
	private String birthday;
	/** 対戦モンスター */
	private String targetMons;
	/** 経験値 */
	private int expoint;
	/** レベル */
	private int level;

	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name セットする name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return sex
	 */
	public int getSex() {
		return sex;
	}
	/**
	 * @param sex セットする sex
	 */
	public void setSex(int sex) {
		this.sex = sex;
	}
	/**
	 * @return pwd
	 */
	public String getPwd() {
		return pwd;
	}
	/**
	 * @param pwd セットする pwd
	 */
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	/**
	 * @return job
	 */
	public int getJob() {
		return job;
	}
	/**
	 * @param job セットする job
	 */
	public void setJob(int job) {
		this.job = job;
	}
	/**
	 * @return address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address セットする address
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return birthday
	 */
	public String getBirthday() {
		return birthday;
	}
	/**
	 * @param birthday セットする birthday
	 */
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	/**
	 * @return targetMons
	 */
	public String getTargetMons() {
		return targetMons;
	}
	/**
	 * @param targetMons セットする targetMons
	 */
	public void setTargetMons(String targetMons) {
		this.targetMons = targetMons;
	}
	/**
	 * @return expoint
	 */
	public int getExpoint() {
		return expoint;
	}
	/**
	 * @param expoint セットする expoint
	 */
	public void setExpoint(int expoint) {
		this.expoint = expoint;
	}
	/**
	 * @return level
	 */
	public int getLevel() {
		return level;
	}
	/**
	 * @param level セットする level
	 */
	public void setLevel(int level) {
		this.level = level;
	}

}
