/**
 *
 */
package jp.ac.asojuku.dq.action;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author nishino
 *
 * 登録画面の表示処理
 *
 */
public class EntryMemberStartAction extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//登録画面表示
		RequestDispatcher rd = req.getRequestDispatcher("view/entry.jsp");
		rd.forward(req, resp);
	}
}
