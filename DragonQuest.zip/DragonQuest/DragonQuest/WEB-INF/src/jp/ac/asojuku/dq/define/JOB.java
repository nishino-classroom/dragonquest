/**
 *
 */
package jp.ac.asojuku.dq.define;

/**
 * @author nishino
 * 仕事定数
 */
public class JOB {
	public static final int SORYO = 0;		//僧侶
	public static final int BUTOUKA = 1;	//武闘家
	public static final int MAHO = 2;		//魔法使い
	public static final int ODORIKO = 3;	//踊り子
	public static final int TOUZOKU = 4;	//盗賊
	public static final int TABIGEININ = 5;	//旅芸人
	public static final int HITSUJIKAI = 6;	//羊飼い
	public static final int GINYUSIJIN = 7;	//吟遊詩人
	public static final int WARAWASESHI = 8;	//笑わせ師
	public static final int SHONIN = 9;		//商人
	public static final int FUNANORI = 10;	//船乗り
	public static final int ASOBININ = 11;	//遊び人
	public static final int BATTLEMASTER = 12;	//バトルマスター
	public static final int MAHOSENSHI = 13;	//魔法戦士
	public static final int KENJA = 14;		//賢者
	public static final int SUPERSTAR = 15;	//スーパースター
	public static final int MAMONOMASTER = 16;	//魔物マスター
	public static final int RENGER = 17;	//レンジャー
	public static final int KAIZOKU = 18;	//海賊
	public static final int PARADIN = 19;	//パラディン
	public static final int GODHAND = 20;	//ゴッドハンド
	public static final int TENTIRAIMEISHI = 21;	//天地雷鳴士
	public static final int YUSHA = 22;		//勇者
}
