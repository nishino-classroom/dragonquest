/**
 *
 */
package jp.ac.asojuku.dq.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author nishino
 * チェックメソッドのユーティリティ
 *
 */
public class ValidateUtils {

	/**
	 * 文字列の長さが指定した範囲内かをチェックする
	 * 文字列がNULLの場合はFALSEが返る
	 *
	 * @param value　チェック対象文字列
	 * @param min　最小値
	 * @param max　最大値
	 * @return　チェック結果
	 */
	public static boolean chkLenRange(String value,int min,int max){
		boolean result = false;

		if( value == null ){
			return false;
		}

		int len = value.length();

		if( ( min <= len ) && ( len <= max ) ){
			result = true;
		}


		return result;
	}

	/**
	 * 文字列の数値チェック
	 *
	 * @param value　チェック対象
	 * @return　true（数値）/false（数値以外の文字列を含む）
	 */
	public static boolean isNumeric(String value) {
		boolean result = false;

		if (value == null) {
			return false;
		}

		try {
			Integer.parseInt(value);
			result = true;
		} catch (NumberFormatException e) {
			result = false;
		}

		return result;
	}

	/**
	 * 文字列が指定されたフォーマットにのっとった
	 * 日付かどうかを返す
	 *
	 * @param value　対象文字列
	 * @param format　日付指定フォーマット
	 * @return
	 */
	public static boolean isDate(String value,String format){
		boolean result = false;

		if (value == null) {
			return false;
		}

        SimpleDateFormat sdf = new SimpleDateFormat(format);

        try {
            // Date型変換
			sdf.parse(value);
			//変換中エラーが起きなければOK
			result = true;
		} catch (ParseException e) {
			result = false;
		}

		return result;
	}

	/**
	 * パスワードのフォーマットチェック
	 * 正規表現を用いて以下を検査
	 * 半角英数記号を最低１種類含み４文字以上
	 * @param value
	 * @return
	 */
	public static boolean isOkPassword(String value){

		if (value == null) {
			return false;
		}

		 Pattern p = Pattern.compile("^(?=.*[0-9])(?=.*[A-Za-z])(?=.*[!\\x22\\#$%&@'()*+,-./_])[\\w!\\x22\\#$%&@'()*+,-./]{4,}$");

		 Matcher m = p.matcher(value);


		return m.matches();
	}


	/**
	 * 文字列が指定された候補と一致するかを確認する
	 * @param value
	 * @param range
	 * @return
	 */
	public static boolean isStringRange(String value,String[] range){
		boolean result = false;

		if (value == null) {
			return false;
		}

		for( String check : range ){
			if( value.equals(check) ){
				result = true;
				break;
			}
		}

		return result;
	}
}
